// Julio Arboleda
// Implementation of System Call Functions
// process_log.c

#include "process_log.h"

int get_proc_log_level(){
	int ret_value = syscall(GET_LOG_LEVEL);
	if(ret_value == -1)
        {
                return ret_value;
        }
        return ret_value;
}

int set_proc_log_level(int new_level){
	int ret_value =  syscall(SET_LOG_LEVEL, new_level);
	if(ret_value == -1)
        {
                return ret_value;
        }
        return ret_value;
}

int proc_log_message(int level, char *message){
	int ret_value = syscall(PROC_LOG_CALL, message, level);
	if(ret_value == -1)
        {
                return ret_value;
        }
        return ret_value;
}

// Harness Functions

int* retrieve_set_level_params(int new_level){
	int* params = malloc(3 * sizeof(int));
	params[0] = SET_LOG_LEVEL;
	params[1] = 1;
	params[2] = new_level;

	return params;
}

int* retrieve_get_level_params(){
	int* params = malloc(2 * sizeof(int));
	params[0] = GET_LOG_LEVEL;
	params[1] = 0;

	return params;
}

int interpret_set_level_result(int ret_value){
	return ret_value;
}

int interpret_get_level_result(int ret_value){
        return ret_value;
}

int interpret_log_message_result(int ret_value){
        return ret_value;
}

