#include <iostream>
#include <iomanip>
#include <unistd.h>
#include <sys/types.h>
#include <errno.h>
#include <string.h>
#include <vector>

extern "C" {
    #include "process_log/process_log.h"
}

using namespace std;

// Colors for terminal output
#define RESET   "\033[0m"
#define RED     "\033[31m"
#define GREEN   "\033[32m"
#define YELLOW  "\033[33m"

bool re_elevate_privileges() {
    if (setresgid(0, 0, 0) == -1 || setresuid(0, 0, 0) == -1) return false;
    return true;
}

void print_result(string test_name, int expected, int actual) {
    bool passed = (expected == actual);
    cout << left << setw(45) << test_name;
    cout << "Expected: " << setw(5) << expected;
    cout << "Got: " << setw(5) << actual;
    if (passed) cout << GREEN << " [PASS]" << RESET << endl;
    else cout << RED << " [FAIL]" << RESET << endl;
}

int main() {
    cout << YELLOW << "--- STARTING COMPREHENSIVE SYSTEM CALL TESTS ---" << RESET << endl << endl;

    // --- TEST 1: GET LOG LEVEL ---
    int current = get_proc_log_level();
    cout << "Initial Log Level is: " << current << endl;

    // --- TEST 2: SET LOG LEVEL (ROOT REQUIRED) ---
    if (getuid() != 0) {
        cout << RED << "Warning: Not running as root. SetLevel tests will fail." << RESET << endl;
    }
    
    int set_res = set_proc_log_level(5);
    print_result("Set Log Level to 5", 0, set_res);
    print_result("Verify Get Log Level is 5", 5, get_proc_log_level());

    // --- TEST 3: RANGE VALIDATION ---
    print_result("Set Log Level to -1 (Invalid)", -1, set_proc_log_level(-1));
    print_result("Set Log Level to 8 (Invalid)", -1, set_proc_log_level(8));

    // --- TEST 4: LOG MESSAGE FILTERING ---
    set_proc_log_level(3); // System level is ERR
    // Level 2 (CRIT) is more severe than 3 (ERR), so it should return 2
    print_result("Log Msg Level 2 (Should be allowed)", 2, proc_log_message(2, (char*)"Visible message"));
    // Level 5 (NOTICE) is less severe than 3 (ERR), so it should be filtered
    print_result("Log Msg Level 5 (Should be filtered)", 5, proc_log_message(5, (char*)"Hidden message"));

    // --- TEST 5: SAFE USER COPY ---
    // Passing a clearly invalid pointer address
    char* bad_ptr = (char*)0x12345678; 
    // We expect -1 from the library, but errno should be EFAULT (14)
    int copy_res = proc_log_message(1, bad_ptr);
    
    cout << left << setw(45) << "Safe Copy Test (Bad Pointer)";
    if (errno == EFAULT || copy_res == -1) {
        cout << GREEN << " [PASS] (Caught Bad Pointer)" << RESET << endl;
    } else {
        cout << RED << " [FAIL] (Did not catch bad pointer)" << RESET << endl;
    }

    cout << endl << YELLOW << "--- TESTS COMPLETE ---" << RESET << endl;
    return 0;
}
